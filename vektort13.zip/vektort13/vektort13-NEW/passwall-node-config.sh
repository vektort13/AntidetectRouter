#!/bin/sh
# Parse query string
ACTION=$(echo "$QUERY_STRING" | grep -o "action=[^&]*" | cut -d= -f2)
NODE_ID=$(echo "$QUERY_STRING" | grep -o "node=[^&]*" | cut -d= -f2)
echo "$QUERY_STRING" > /tmp/query-debug.txt
echo "---" >> /tmp/query-debug.txt
# Read POST data (for future use)
read -r POST_DATA

# Handle save action - convert to create/update
if [ "$ACTION" = "save" ]; then
    if [ "$NODE_ID" = "new" ] || [ -z "$NODE_ID" ]; then
        ACTION="create"
    else
        ACTION="update"
    fi
fi

get_param() {
	echo "$QUERY_STRING" | grep -o "$1=[^&]*" | cut -d= -f2 | sed 's/%20/ /g; s/%2F/\//g' | head -n1 | tr -d '\r'
}
case "$ACTION" in
    create)
        # Parse from QUERY_STRING
        REMARKS=$(get_param "remarks")
        TYPE=$(get_param "type")
        PROTOCOL=$(get_param "protocol")
        ADDRESS=$(get_param "address")
        PORT=$(get_param "port")
{
    echo "=== DEBUG $(date) ==="
    echo "RAW PORT: [$PORT]"
    echo "PORT length: ${#PORT}"
    echo "PORT hex: $(echo -n "$PORT" | od -An -tx1)"
} >> /tmp/port-debug.log
        
        if [ -z "$REMARKS" ] || [ -z "$ADDRESS" ] || [ -z "$PORT" ]; then
            echo '{"status":"error","message":"Missing required fields: remarks, address, port"}'
            exit 1
        fi
        
        # Generate unique section name
        SECTION="node_$(date +%s)"
        
        # Create node in UCI
        uci set passwall.$SECTION=nodes
        uci set passwall.$SECTION.remarks="$REMARKS"
        uci set passwall.$SECTION.type="${TYPE:-Xray}"
        uci set passwall.$SECTION.address="$ADDRESS"
	PORT_CLEAN=$(echo "$PORT" | tr -d '\n\r\t' | xargs)
        uci set passwall.$SECTION.port="$PORT_CLEAN"
        
        # Protocol
        if [ -n "$PROTOCOL" ]; then
            uci set passwall.$SECTION.protocol="$PROTOCOL"
        fi
        
        # Optional fields
        USERNAME=$(get_param "username")
        PASSWORD=$(get_param "password")
        UUID=$(get_param "uuid")
        
        [ -n "$USERNAME" ] && uci set passwall.$SECTION.username="$USERNAME"
        [ -n "$PASSWORD" ] && uci set passwall.$SECTION.password="$PASSWORD"
        [ -n "$UUID" ] && uci set passwall.$SECTION.uuid="$UUID"
        
        uci commit passwall
        /etc/init.d/passwall restart >/dev/null 2>&1 &
        
        echo "{\"status\":\"ok\",\"message\":\"Node created\",\"id\":\"$SECTION\"}"
        ;;
        
    update)
        if [ -z "$NODE_ID" ]; then
            echo '{"status":"error","message":"Node ID required"}'
            exit 1
        fi
        
        # Update fields
        REMARKS=$(get_param "remarks")
        ADDRESS=$(get_param "address")
        PORT=$(get_param "port")
	PORT_CLEAN=$(echo "$PORT" | tr -d '\n\r\t' | xargs)
	[ -n "$PORT_CLEAN" ] && uci set passwall.$NODE_ID.port="$PORT_CLEAN"
        
        [ -n "$REMARKS" ] && uci set passwall.$NODE_ID.remarks="$REMARKS"
        [ -n "$ADDRESS" ] && uci set passwall.$NODE_ID.address="$ADDRESS"
        [ -n "$PORT" ] && uci set passwall.$NODE_ID.port="$PORT"
        
        uci commit passwall
        /etc/init.d/passwall restart >/dev/null 2>&1 &
        
        echo '{"status":"ok","message":"Node updated"}'
        ;;
        
    delete)
        if [ -z "$NODE_ID" ]; then
            echo '{"status":"error","message":"Node ID required"}'
            exit 1
        fi
        
        uci delete passwall.$NODE_ID
        uci commit passwall
        /etc/init.d/passwall restart >/dev/null 2>&1 &
        
        echo '{"status":"ok","message":"Node deleted"}'
        ;;
        
    *)
        echo '{"status":"error","message":"Unknown action"}'
        ;;
esac
