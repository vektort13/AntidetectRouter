#!/bin/sh
# Snapshot Generator - запускает /root/mega-snapshot.sh и возвращает архив

# Parse query parameters
if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
fi

ACTION="${action:-create}"

case "$ACTION" in
    create)
        # Generate unique snapshot name
        TIMESTAMP=$(date '+%Y%m%d-%H%M%S')
        SNAPSHOT_NAME="snapshot-$TIMESTAMP"
        
        # Run mega-snapshot.sh
        if [ ! -f /root/mega-snapshot.sh ]; then
            echo "Content-type: application/json"
            echo "Access-Control-Allow-Origin: *"
            echo ""
            echo '{"status":"error","message":"mega-snapshot.sh not found at /root/mega-snapshot.sh"}'
            exit 1
        fi
        
        chmod +x /root/mega-snapshot.sh
        
        # Execute snapshot (redirect output to log)
        /root/mega-snapshot.sh "$SNAPSHOT_NAME" > /tmp/snapshot-creation.log 2>&1
        
        SNAPSHOT_DIR="/root/snapshots/$SNAPSHOT_NAME"
        
        if [ ! -d "$SNAPSHOT_DIR" ]; then
            echo "Content-type: application/json"
            echo "Access-Control-Allow-Origin: *"
            echo ""
            echo '{"status":"error","message":"Snapshot creation failed"}'
            exit 1
        fi
        
        # Create tar.gz archive
        ARCHIVE_PATH="/tmp/${SNAPSHOT_NAME}.tar.gz"
        cd /root/snapshots
        tar -czf "$ARCHIVE_PATH" "$SNAPSHOT_NAME/" 2>/dev/null
        
        if [ ! -f "$ARCHIVE_PATH" ]; then
            echo "Content-type: application/json"
            echo "Access-Control-Allow-Origin: *"
            echo ""
            echo '{"status":"error","message":"Archive creation failed"}'
            exit 1
        fi
        
        # Return download URL
        echo "Content-type: application/json"
        echo "Access-Control-Allow-Origin: *"
        echo ""
        cat << EOF
{
  "status": "ok",
  "message": "Snapshot created successfully",
  "snapshot_name": "$SNAPSHOT_NAME",
  "archive_path": "$ARCHIVE_PATH",
  "download_url": "/cgi-bin/snapshot.sh?action=download&file=${SNAPSHOT_NAME}.tar.gz"
}
EOF
        ;;
        
    download)
        # Download the archive
        FILE="${file}"
        FILE_PATH="/tmp/$FILE"
        
        if [ ! -f "$FILE_PATH" ]; then
            echo "Content-type: application/json"
            echo "Access-Control-Allow-Origin: *"
            echo ""
            echo '{"status":"error","message":"File not found"}'
            exit 1
        fi
        
        # Send file for download
        echo "Content-Type: application/gzip"
        echo "Content-Disposition: attachment; filename=\"$FILE\""
        echo "Access-Control-Allow-Origin: *"
        echo ""
        cat "$FILE_PATH"
        
        # Clean up after download
        rm -f "$FILE_PATH"
        ;;
        
    *)
        echo "Content-type: application/json"
        echo "Access-Control-Allow-Origin: *"
        echo ""
        echo '{"status":"error","message":"Invalid action"}'
        ;;
esac
