#!/bin/sh
echo "Content-Type: application/json"
echo ""

ACTION=$(echo "$QUERY_STRING" | grep -o "action=[^&]*" | cut -d= -f2)
NODE=$(echo "$QUERY_STRING" | grep -o "node=[^&]*" | cut -d= -f2)

case "$ACTION" in
    list)
        # List all Passwall nodes with full details
        NODES=""
        for node in $(uci show passwall 2>/dev/null | grep "=nodes" | cut -d. -f2 | cut -d= -f1); do
            if [ -n "$NODES" ]; then
                NODES="$NODES,"
            fi
            
            # Get node properties
            REMARKS=$(uci get passwall.$node.remarks 2>/dev/null || echo "")
            TYPE=$(uci get passwall.$node.type 2>/dev/null || echo "Xray")
            PROTOCOL=$(uci get passwall.$node.protocol 2>/dev/null || echo "N/A")
            ADDRESS=$(uci get passwall.$node.address 2>/dev/null || echo "N/A")
            PORT=$(uci get passwall.$node.port 2>/dev/null || echo "N/A")
            TLS=$(uci get passwall.$node.tls 2>/dev/null || echo "0")
            TRANSPORT=$(uci get passwall.$node.transport 2>/dev/null || echo "tcp")
            
            # ULTRA aggressive cleaning - ONLY alphanumeric, space, dash, underscore
            # Remove everything else including slashes, dots, special chars
            REMARKS_CLEAN=$(echo "$REMARKS" | tr -cd 'a-zA-Z0-9 _-' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | head -c 50)
            
            # If empty or very short (less than 2 chars), use node ID
            if [ -z "$REMARKS_CLEAN" ] || [ ${#REMARKS_CLEAN} -lt 2 ]; then
                REMARKS_CLEAN="Node_${node}"
            fi
            
            # Escape for JSON (only needed for quotes and backslashes now)
            REMARKS_SAFE=$(echo "$REMARKS_CLEAN" | sed 's/\\/\\\\/g; s/"/\\"/g')
            
            # Clean other fields
            TYPE_SAFE=$(echo "$TYPE" | tr -cd 'a-zA-Z0-9')
            PROTOCOL_SAFE=$(echo "$PROTOCOL" | tr -cd 'a-zA-Z0-9_-')
            ADDRESS_SAFE=$(echo "$ADDRESS" | tr -cd 'a-zA-Z0-9.:_-')
            PORT_SAFE=$(echo "$PORT" | tr -cd '0-9')
            
            NODES="$NODES{\"id\":\"$node\",\"name\":\"$REMARKS_SAFE\",\"type\":\"$TYPE_SAFE\",\"protocol\":\"$PROTOCOL_SAFE\",\"address\":\"$ADDRESS_SAFE\",\"port\":\"$PORT_SAFE\",\"tls\":\"$TLS\",\"transport\":\"$TRANSPORT\"}"
        done
        
        echo "{\"status\":\"ok\",\"nodes\":[$NODES]}"
        ;;
    
    get)
        # Get full node configuration
        if [ -n "$NODE" ]; then
            REMARKS=$(uci get passwall.$NODE.remarks 2>/dev/null || echo "")
            TYPE=$(uci get passwall.$NODE.type 2>/dev/null || echo "")
            PROTOCOL=$(uci get passwall.$NODE.protocol 2>/dev/null || echo "")
            ADDRESS=$(uci get passwall.$NODE.address 2>/dev/null || echo "")
            PORT=$(uci get passwall.$NODE.port 2>/dev/null || echo "")
            USERNAME=$(uci get passwall.$NODE.username 2>/dev/null || echo "")
            PASSWORD=$(uci get passwall.$NODE.password 2>/dev/null || echo "")
            UUID=$(uci get passwall.$NODE.uuid 2>/dev/null || echo "")
            TLS=$(uci get passwall.$NODE.tls 2>/dev/null || echo "0")
            TRANSPORT=$(uci get passwall.$NODE.transport 2>/dev/null || echo "tcp")
            
            cat << EOF
{"status":"ok","node":{"id":"$NODE","remarks":"$REMARKS","type":"$TYPE","protocol":"$PROTOCOL","address":"$ADDRESS","port":"$PORT","username":"$USERNAME","password":"$PASSWORD","uuid":"$UUID","tls":"$TLS","transport":"$TRANSPORT"}}
EOF
        else
            echo '{"status":"error","message":"Node ID required"}'
        fi
        ;;
    
    ping)
        # Ping node
        if [ -n "$NODE" ]; then
            ADDRESS=$(uci get passwall.$NODE.address 2>/dev/null)
            if [ -n "$ADDRESS" ]; then
                LATENCY=$(ping -c 1 -W 2 "$ADDRESS" 2>/dev/null | grep "time=" | sed 's/.*time=\([0-9.]*\).*/\1/')
                if [ -n "$LATENCY" ]; then
                    echo "{\"status\":\"ok\",\"latency\":\"${LATENCY}ms\"}"
                else
                    echo '{"status":"error","message":"Timeout"}'
                fi
            else
                echo '{"status":"error","message":"Node not found"}'
            fi
        else
            echo '{"status":"error","message":"Node ID required"}'
        fi
        ;;
    
    delete)
        # Delete node
        if [ -n "$NODE" ]; then
            uci delete passwall.$NODE 2>/dev/null
            uci commit passwall
            /etc/init.d/passwall restart >/dev/null 2>&1 &
            echo '{"status":"ok","message":"Node deleted"}'
        else
            echo '{"status":"error","message":"Node ID required"}'
        fi
        ;;
        
    save)
        # Redirect to passwall-node-config.sh
        exec /www/cgi-bin/vektort13/passwall-node-config.sh
        ;;
    
    *)
        echo '{"status":"error","message":"Unknown action: '"$ACTION"'"}'
        ;;
esac
