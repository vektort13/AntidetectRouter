#!/bin/sh
# OpenVPN Get Content - returns plain text content of .ovpn file

CONFIG=$(echo "$QUERY_STRING" | grep -o "config=[^&]*" | cut -d= -f2)

if [ -z "$CONFIG" ]; then
    echo "Content-Type: application/json"
    echo ""
    echo '{"status":"error","message":"Config name required"}'
    exit 1
fi

# Get config file path from UCI
CONFIG_PATH=$(uci get openvpn.${CONFIG}.config 2>/dev/null)

if [ -z "$CONFIG_PATH" ]; then
    echo "Content-Type: application/json"
    echo ""
    echo '{"status":"error","message":"No config file path found. This may be a UCI-only config."}'
    exit 1
fi

if [ ! -f "$CONFIG_PATH" ]; then
    echo "Content-Type: application/json"
    echo ""
    echo "{\"status\":\"error\",\"message\":\"File not found: $CONFIG_PATH\"}"
    exit 1
fi

# Return plain text content
echo "Content-Type: text/plain"
echo ""
cat "$CONFIG_PATH"
