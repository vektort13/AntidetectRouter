#!/bin/sh
echo "Content-type: application/json"
echo "Access-Control-Allow-Origin: *"
echo ""

if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
else
    for arg in "$@"; do
        eval "$arg"
    done
fi

ACTION="${action:-status}"

get_status() {
    UPTIME=$(uptime | sed 's/.*up //' | sed 's/,.*load.*//' | sed 's/,.*//' | xargs)
    
    cat << EOF
{
  "status": "ok",
  "uptime": "$UPTIME"
}
EOF
}

do_reboot() {
    echo '{"status":"ok","message":"Rebooting..."}'
    sleep 1
    reboot &
}

backup_config() {
    BACKUP_FILE="/tmp/backup-$(date +%Y%m%d-%H%M%S).tar.gz"
    sysupgrade -b "$BACKUP_FILE" >/dev/null 2>&1
    
    if [ -f "$BACKUP_FILE" ]; then
        echo "{\"status\":\"ok\",\"file\":\"$BACKUP_FILE\"}"
    else
        echo '{"status":"error","message":"Backup failed"}'
    fi
}

restore_config() {
    # This would need file upload handling
    echo '{"status":"error","message":"Not implemented"}'
}

case "$ACTION" in
    status) get_status ;;
    reboot) do_reboot ;;
    backup) backup_config ;;
    restore) restore_config ;;
    *) echo '{"status":"error","message":"Invalid action"}' ;;
esac
