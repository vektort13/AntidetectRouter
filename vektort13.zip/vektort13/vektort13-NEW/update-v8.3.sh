#!/bin/sh
# VEKTORT13 v8.3 UPDATE - LOGS + FIXED BUTTONS

echo "=========================================="
echo "VEKTORT13 v8.3 UPDATE"
echo "=========================================="
echo ""

echo "NEW FEATURES:"
echo "  ✓ Logs button for each OpenVPN config"
echo "  ✓ Fixed Start/Stop button sizes"
echo "  ✓ Toast for Options errors"
echo "  ✓ Live log viewer with auto-update"
echo "  ✓ RW server protection"
echo ""

echo "[1] Backing up..."
cp /www/vektort13-admin/app.js /www/vektort13-admin/app.js.backup 2>/dev/null
cp /www/vektort13-admin/style.css /www/vektort13-admin/style.css.backup 2>/dev/null
cp /www/vektort13-admin/index.html /www/vektort13-admin/index.html.backup 2>/dev/null
echo "  ✓ Backups created"

echo ""
echo "[2] Installing files..."
cp app.js /www/vektort13-admin/app.js
cp style.css /www/vektort13-admin/style.css
cp index.html /www/vektort13-admin/index.html
cp openvpn-control.sh /www/cgi-bin/vektort13/openvpn-control.sh
cp vpn-control.sh /www/cgi-bin/vektort13/vpn-control.sh

chmod +x /www/cgi-bin/vektort13/*.sh
echo "  ✓ Files installed"

echo ""
echo "=========================================="
echo "✅ v8.3 INSTALLED"
echo "=========================================="
echo ""

echo "WHAT'S NEW:"
echo ""
echo "1. Logs Button 📋"
echo "   • Added between Stop and Edit"
echo "   • Shows logs for specific config only"
echo "   • Auto-updates every 5 seconds"
echo "   • Pause/Resume/Download options"
echo ""
echo "2. Fixed Button Sizes"
echo "   BEFORE:"
echo "     [▶️ Start        ]  ← Wide (2 buttons worth)"
echo "     [🔄 Restart] [⏹️ Stop]  ← 2 separate buttons"
echo ""
echo "   AFTER:"
echo "     [▶️ Start] [        ]  ← Same width (placeholder)"
echo "     [🔄 Restart] [⏹️ Stop]  ← Same width"
echo ""
echo "3. Options Error Toast"
echo "   When config has errors like:"
echo "     'Unrecognized option: block-outside-dns'"
echo "   Shows special error toast with details"
echo ""
echo "4. RW Protection 🛡️"
echo "   • Never kills openvpn(rw) process"
echo "   • Only manages client connections"
echo "   • Safe start/stop/restart"
echo ""
echo "=========================================="
echo "REFRESH BROWSER:"
echo "  http://$(uci get network.lan.ipaddr 2>/dev/null || echo 'YOUR_IP')/vektort13-admin/"
echo ""
echo "Hard refresh: Ctrl+Shift+R"
echo "=========================================="
echo ""
echo "HOW TO USE LOGS:"
echo ""
echo "1. Go to: OpenVPN page"
echo "2. Find your config"
echo "3. Click: [📋 Logs] button"
echo "4. Modal window opens with:"
echo "   • Real-time logs (auto-update)"
echo "   • [⏸️ Pause] - Stop auto-update"
echo "   • [🗑️ Clear] - Clear display"
echo "   • [⬇️ Download] - Download as .txt"
echo ""
echo "Logs are filtered to show ONLY this config!"
echo "=========================================="
