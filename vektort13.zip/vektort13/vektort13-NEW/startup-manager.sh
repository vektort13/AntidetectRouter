#!/bin/sh
echo "Content-type: application/json"
echo "Access-Control-Allow-Origin: *"
echo ""

if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
else
    for arg in "$@"; do
        eval "$arg"
    done
fi

ACTION="${action:-list}"

list_services() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "services": ['
    
    FIRST=1
    for service in /etc/init.d/*; do
        [ -x "$service" ] || continue
        NAME=$(basename "$service")
        
        # Skip certain services
        case "$NAME" in
            boot|done|rcS) continue ;;
        esac
        
        # Check if enabled
        ENABLED="false"
        ls /etc/rc.d/*"$NAME" >/dev/null 2>&1 && ENABLED="true"
        
        # Check if running
        RUNNING="false"
        "$service" running >/dev/null 2>&1 && RUNNING="true"
        
        [ "$FIRST" = "1" ] && FIRST=0 || echo ","
        echo "    {\"name\": \"$NAME\", \"enabled\": $ENABLED, \"running\": $RUNNING}"
    done
    
    echo '  ]'
    echo '}'
}

control_service() {
    SVC="${service}"
    CMD="${command}"
    
    if [ -z "$SVC" ] || [ -z "$CMD" ]; then
        echo '{"status":"error","message":"Service and command required"}'
        return
    fi
    
    case "$CMD" in
        enable)
            /etc/init.d/"$SVC" enable
            echo "{\"status\":\"ok\",\"message\":\"$SVC enabled\"}"
            ;;
        disable)
            /etc/init.d/"$SVC" disable
            echo "{\"status\":\"ok\",\"message\":\"$SVC disabled\"}"
            ;;
        start)
            /etc/init.d/"$SVC" start
            echo "{\"status\":\"ok\",\"message\":\"$SVC started\"}"
            ;;
        stop)
            /etc/init.d/"$SVC" stop
            echo "{\"status\":\"ok\",\"message\":\"$SVC stopped\"}"
            ;;
        restart)
            /etc/init.d/"$SVC" restart
            echo "{\"status\":\"ok\",\"message\":\"$SVC restarted\"}"
            ;;
        *)
            echo '{"status":"error","message":"Invalid command"}'
            ;;
    esac
}

case "$ACTION" in
    list) list_services ;;
    control) control_service ;;
    *) echo '{"status":"error","message":"Invalid action"}' ;;
esac
