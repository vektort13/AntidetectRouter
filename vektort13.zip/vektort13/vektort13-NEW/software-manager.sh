#!/bin/sh
echo "Content-type: application/json"
echo "Access-Control-Allow-Origin: *"
echo ""

if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
else
    for arg in "$@"; do
        eval "$arg"
    done
fi

ACTION="${action:-list}"

list_packages() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "packages": ['
    
    FIRST=1
    opkg list-installed | while read pkg version rest; do
        [ "$FIRST" = "1" ] && FIRST=0 || echo ","
        echo "    {\"name\": \"$pkg\", \"version\": \"$version\"}"
    done
    
    echo '  ]'
    echo '}'
}

update_lists() {
    opkg update >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo '{"status":"ok","message":"Package lists updated"}'
    else
        echo '{"status":"error","message":"Update failed"}'
    fi
}

install_package() {
    PKG="${package}"
    if [ -z "$PKG" ]; then
        echo '{"status":"error","message":"Package name required"}'
        return
    fi
    
    opkg install "$PKG" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "{\"status\":\"ok\",\"message\":\"$PKG installed\"}"
    else
        echo "{\"status\":\"error\",\"message\":\"Failed to install $PKG\"}"
    fi
}

remove_package() {
    PKG="${package}"
    if [ -z "$PKG" ]; then
        echo '{"status":"error","message":"Package name required"}'
        return
    fi
    
    opkg remove "$PKG" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "{\"status\":\"ok\",\"message\":\"$PKG removed\"}"
    else
        echo "{\"status\":\"error\",\"message\":\"Failed to remove $PKG\"}"
    fi
}

case "$ACTION" in
    list) list_packages ;;
    update) update_lists ;;
    install) install_package ;;
    remove) remove_package ;;
    *) echo '{"status":"error","message":"Invalid action"}' ;;
esac
