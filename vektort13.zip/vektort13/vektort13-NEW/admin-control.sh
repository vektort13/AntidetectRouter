#!/bin/sh
echo "Content-type: application/json"
echo "Access-Control-Allow-Origin: *"
echo ""

if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
else
    for arg in "$@"; do
        eval "$arg"
    done
fi

ACTION="${action:-status}"

get_status() {
    SSH_PORT=$(uci get dropbear.@dropbear[0].Port 2>/dev/null || echo 22)
    LUCI_PORT=$(uci get uhttpd.main.listen_http 2>/dev/null | grep -o "[0-9]*" || echo 80)
    SSH_ENABLED=$(pgrep dropbear >/dev/null && echo "true" || echo "false")
    
    cat << EOF
{
  "status": "ok",
  "ssh_port": "$SSH_PORT",
  "luci_port": "$LUCI_PORT",
  "ssh_enabled": $SSH_ENABLED
}
EOF
}

set_ssh_port() {
    PORT="${port}"
    if [ -z "$PORT" ]; then
        echo '{"status":"error","message":"Port required"}'
        return
    fi
    
    uci set dropbear.@dropbear[0].Port="$PORT"
    uci commit dropbear
    /etc/init.d/dropbear restart
    
    echo "{\"status\":\"ok\",\"message\":\"SSH port changed to $PORT\"}"
}

set_luci_port() {
    PORT="${port}"
    if [ -z "$PORT" ]; then
        echo '{"status":"error","message":"Port required"}'
        return
    fi
    
    uci set uhttpd.main.listen_http="0.0.0.0:$PORT"
    uci set uhttpd.main.listen_https="0.0.0.0:$((PORT + 363))"
    uci commit uhttpd
    /etc/init.d/uhttpd restart
    
    echo "{\"status\":\"ok\",\"message\":\"LuCI port changed to $PORT\"}"
}

set_password() {
    POST_DATA=$(cat)
    NEW_PASS=$(echo "$POST_DATA" | grep -o '"password":"[^"]*' | cut -d'"' -f4)
    
    if [ -z "$NEW_PASS" ]; then
        echo '{"status":"error","message":"Password required"}'
        return
    fi
    
    echo -e "$NEW_PASS\n$NEW_PASS" | passwd root >/dev/null 2>&1
    
    if [ $? -eq 0 ]; then
        echo '{"status":"ok","message":"Password changed"}'
    else
        echo '{"status":"error","message":"Failed to change password"}'
    fi
}

case "$ACTION" in
    status) get_status ;;
    set_ssh_port) set_ssh_port ;;
    set_luci_port) set_luci_port ;;
    set_password) set_password ;;
    *) echo '{"status":"error","message":"Invalid action"}' ;;
esac
