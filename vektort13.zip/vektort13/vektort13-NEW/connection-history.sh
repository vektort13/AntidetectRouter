#!/bin/sh
# Connection History - хранит последние 20-25 записей latency

HISTORY_FILE="/tmp/vpn-connection-history.log"
MAX_ENTRIES=25

echo "Content-type: application/json"
echo "Access-Control-Allow-Origin: *"
echo ""

# Parse parameters
if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
fi

ACTION="${action:-read}"

case "$ACTION" in
    read)
        # Read history file
        if [ ! -f "$HISTORY_FILE" ]; then
            echo '{"status":"ok","entries":[]}'
            exit 0
        fi
        
        echo '{"status":"ok","entries":['
        
        FIRST=1
        while IFS='|' read -r timestamp latency mode ip; do
            # Skip N/A entries
            if [ "$latency" = "N/A" ] || [ "$ip" = "N/A" ] || [ "$mode" = "Unknown" ]; then
                continue
            fi
            
            [ "$FIRST" = "1" ] && FIRST=0 || echo ","
            cat << EOF
{
  "timestamp": "$timestamp",
  "latency": "$latency",
  "mode": "$mode",
  "ip": "$ip"
}
EOF
        done < "$HISTORY_FILE"
        
        echo ']}'
        ;;
        
    add)
        # Add new entry
        TIMESTAMP="${timestamp:-$(date '+%H:%M:%S')}"
        LATENCY="${latency:-N/A}"
        MODE="${mode:-Unknown}"
        LOCATION="${location:-Unknown}"
        IP="${ip:-Unknown}"
        
        # Append to file
        echo "$TIMESTAMP|$LATENCY|$MODE|$LOCATION|$IP" >> "$HISTORY_FILE"
        
        # Keep only last MAX_ENTRIES
        if [ -f "$HISTORY_FILE" ]; then
            tail -n $MAX_ENTRIES "$HISTORY_FILE" > "${HISTORY_FILE}.tmp"
            mv "${HISTORY_FILE}.tmp" "$HISTORY_FILE"
        fi
        
        echo '{"status":"ok","message":"Entry added"}'
        ;;
        
    clear)
        # Clear history
        rm -f "$HISTORY_FILE"
        echo '{"status":"ok","message":"History cleared"}'
        ;;
        
    *)
        echo '{"status":"error","message":"Invalid action"}'
        ;;
esac
