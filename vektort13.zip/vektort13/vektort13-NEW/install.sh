#!/bin/sh
set -x  # Debug mode

echo "=== VEKTORT13 v13.1 INSTALLATION ==="
echo ""

# Show current directory
echo "Current directory:"
pwd
ls -la *.js *.css *.html 2>/dev/null | head -5

echo ""
echo "Creating directories..."
mkdir -p /www/vektort13-admin
mkdir -p /www/cgi-bin/vektort13

echo ""
echo "Checking directories..."
ls -ld /www/vektort13-admin
ls -ld /www/cgi-bin/vektort13

echo ""
echo "Copying frontend files..."
cp -fv app.js /www/vektort13-admin/
cp -fv network.js /www/vektort13-admin/
cp -fv advanced.js /www/vektort13-admin/
cp -fv style.css /www/vektort13-admin/
cp -fv index.html /www/vektort13-admin/

echo ""
echo "Copying backend files..."
cp -fv *.sh /www/cgi-bin/vektort13/ 2>&1 | grep -E "(exec|admin|software|system|snapshot)"

echo ""
echo "Installing mega-snapshot.sh..."
cp -fv mega-snapshot.sh /root/mega-snapshot.sh
chmod +x /root/mega-snapshot.sh
ls -lh /root/mega-snapshot.sh

echo ""
echo "Installing utility scripts..."
cp -fv show-vpn-status.sh /root/show-vpn-status.sh
cp -fv vpn-dns-monitor.sh /root/vpn-dns-monitor.sh
cp -fv dual-vpn-switcher.sh /root/dual-vpn-switcher.sh
cp -fv dual-vpn-autodetect.sh /root/dual-vpn-autodetect.sh
cp -fv start-all.sh /root/start-all.sh
cp -fv upstream-monitor.sh /root/upstream-monitor.sh
chmod +x /root/*.sh
echo "✓ show-vpn-status.sh → /root/"
echo "✓ vpn-dns-monitor.sh → /root/"
echo "✓ dual-vpn-switcher.sh → /root/"
echo "✓ dual-vpn-autodetect.sh → /root/"
echo "✓ start-all.sh → /root/"
echo "✓ upstream-monitor.sh → /root/"

echo ""
echo "Setting permissions..."
chmod +x /www/cgi-bin/vektort13/*.sh

echo ""
echo "Installing OpenVPN DNS autopatch..."
HOTPLUG_FILE="/usr/libexec/openvpn-hotplug"
BACKUP_FILE="/usr/libexec/openvpn-hotplug.backup"

# Backup original hotplug if exists and not backed up yet
if [ -f "$HOTPLUG_FILE" ] && [ ! -f "$BACKUP_FILE" ]; then
    cp "$HOTPLUG_FILE" "$BACKUP_FILE"
    chmod +x "$BACKUP_FILE"
    echo "✓ Original hotplug backed up: $BACKUP_FILE"
fi

# Install our patched hotplug
cp -fv openvpn-hotplug "$HOTPLUG_FILE"
chmod +x "$HOTPLUG_FILE"
echo "✓ OpenVPN DNS autopatch installed"
echo "✓ DNS will be auto-configured from VPN server push"

echo ""
echo "Cleaning up old history logs..."
rm -f /tmp/vpn-connection-history.log
rm -f /tmp/vpn-last-state
echo "✓ Old logs cleared"

echo ""
echo "Cleaning up old VEKTORT13 modifications..."
# Remove all old VEKTORT13 entries from rc.local
if [ -f /etc/rc.local ]; then
    sed -i '/# VEKTORT13:/d' /etc/rc.local
    sed -i '/uci set passwall.@global\[0\]/d' /etc/rc.local
    sed -i '/uci commit passwall/d' /etc/rc.local
    sed -i '/\/etc\/init\.d\/passwall/d' /etc/rc.local
    echo "✓ Removed old Passwall modifications from rc.local"
fi
echo "✓ Passwall will use standard OpenWrt behavior"

echo ""
echo "Configuring Passwall compatibility..."
# CRITICAL: Disable fw4 firewall (conflicts with Passwall nftables)
if [ -f /etc/init.d/firewall ]; then
    echo "⚠️  Disabling fw4 firewall (conflicts with Passwall)..."
    /etc/init.d/firewall stop 2>/dev/null
    /etc/init.d/firewall disable 2>/dev/null
    
    # Remove firewall symlinks
    rm -f /etc/rc.d/S*firewall* 2>/dev/null
    rm -f /etc/rc.d/K*firewall* 2>/dev/null
    
    # Kill fw4 process
    killall fw4 2>/dev/null
    
    # Delete fw4 nftables if exists
    if command -v nft >/dev/null 2>&1; then
        if nft list table inet fw4 >/dev/null 2>&1; then
            nft delete table inet fw4 2>/dev/null
        fi
    fi
    
    echo "✓ fw4 disabled (Passwall will manage firewall)"
else
    echo "⚠️  fw4 not found, skipping"
fi

# Restart Passwall to create its nftables
if [ -f /etc/init.d/passwall ]; then
    echo "Restarting Passwall to create firewall rules..."
    /etc/init.d/passwall restart 2>/dev/null
    sleep 3
    echo "✓ Passwall restarted"
fi

echo ""
echo "=== VERIFICATION ==="
echo "Frontend files:"
ls -lh /www/vektort13-admin/
echo ""
echo "Backend exec.sh:"
ls -lh /www/cgi-bin/vektort13/exec.sh

echo ""
echo "✓ INSTALLATION COMPLETE"
echo "Refresh browser: Ctrl+Shift+R"
