#!/bin/sh
# Network Diagnostics Tools

echo "Content-type: application/json"
echo "Access-Control-Allow-Origin: *"
echo ""

# Parse parameters
if [ -n "$QUERY_STRING" ]; then
    eval $(echo "$QUERY_STRING" | tr '&' '\n' | while IFS='=' read key value; do
        value=$(echo "$value" | sed 's/+/ /g; s/%\([0-9A-F][0-9A-F]\)/\\x\1/g' | xargs -0 printf "%b" 2>/dev/null)
        echo "${key}='${value}'"
    done)
else
    for arg in "$@"; do
        eval "$arg"
    done
fi

ACTION="${action:-ping}"
HOST="${host:-8.8.8.8}"
COUNT="${count:-4}"

# Ping test
do_ping() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "tool": "ping",'
    echo '  "host": "'$HOST'",'
    echo '  "results": ['
    
    FIRST=1
    ping -c "$COUNT" -W 2 "$HOST" 2>&1 | while read line; do
        if echo "$line" | grep -q "bytes from"; then
            [ "$FIRST" = "1" ] && FIRST=0 || echo ","
            
            SEQ=$(echo "$line" | grep -o "icmp_seq=[0-9]*" | cut -d= -f2)
            TIME=$(echo "$line" | grep -o "time=[0-9.]*" | cut -d= -f2)
            TTL=$(echo "$line" | grep -o "ttl=[0-9]*" | cut -d= -f2)
            
            echo "    {\"seq\": $SEQ, \"time\": \"${TIME}ms\", \"ttl\": $TTL}"
        fi
    done
    
    echo '  ]'
    echo '}'
}

# Traceroute
do_traceroute() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "tool": "traceroute",'
    echo '  "host": "'$HOST'",'
    echo '  "hops": ['
    
    FIRST=1
    traceroute -m 15 -w 2 "$HOST" 2>&1 | tail -n +2 | while read line; do
        [ "$FIRST" = "1" ] && FIRST=0 || echo ","
        
        HOP=$(echo "$line" | awk '{print $1}')
        IP=$(echo "$line" | awk '{print $2}' | tr -d '()')
        TIME=$(echo "$line" | grep -o "[0-9.]*\s*ms" | head -1)
        
        echo "    {\"hop\": $HOP, \"ip\": \"$IP\", \"time\": \"$TIME\"}"
    done
    
    echo '  ]'
    echo '}'
}

# DNS lookup
do_nslookup() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "tool": "nslookup",'
    echo '  "host": "'$HOST'",'
    
    RESULT=$(nslookup "$HOST" 2>&1)
    
    # Extract IPs
    IPS=$(echo "$RESULT" | grep "Address" | tail -n +2 | awk '{print $2}')
    
    echo '  "addresses": ['
    FIRST=1
    for ip in $IPS; do
        [ "$FIRST" = "1" ] && FIRST=0 || echo ","
        echo "    \"$ip\""
    done
    echo '  ]'
    echo '}'
}

# Network scan (simple arp scan)
do_scan() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "tool": "scan",'
    echo '  "devices": ['
    
    FIRST=1
    ip neigh | while read line; do
        IP=$(echo "$line" | awk '{print $1}')
        MAC=$(echo "$line" | awk '{print $5}')
        STATE=$(echo "$line" | grep -o "REACHABLE\|STALE\|DELAY")
        
        if [ -n "$MAC" ] && [ "$MAC" != "FAILED" ]; then
            [ "$FIRST" = "1" ] && FIRST=0 || echo ","
            echo "    {\"ip\": \"$IP\", \"mac\": \"$MAC\", \"state\": \"$STATE\"}"
        fi
    done
    
    echo '  ]'
    echo '}'
}

# Speedtest (simple download test)
do_speedtest() {
    echo '{'
    echo '  "status": "ok",'
    echo '  "tool": "speedtest",'
    
    # Simple test - download from fast.com or similar
    START=$(date +%s)
    curl -o /dev/null -s -w "%{speed_download}" http://speedtest.tele2.net/1MB.zip 2>&1
    DOWNLOAD_SPEED=$?
    
    echo '  "download_mbps": "N/A (not implemented)",'
    echo '  "upload_mbps": "N/A",'
    echo '  "ping_ms": "N/A"'
    echo '}'
}

# Main logic
case "$ACTION" in
    ping)
        do_ping
        ;;
    traceroute)
        do_traceroute
        ;;
    nslookup)
        do_nslookup
        ;;
    scan)
        do_scan
        ;;
    speedtest)
        do_speedtest
        ;;
    *)
        echo '{"status":"error","message":"Invalid action"}'
        ;;
esac
